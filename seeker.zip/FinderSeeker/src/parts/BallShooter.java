package parts;

import lejos.hardware.motor.Motor;

public class BallShooter implements Runnable {

	private Seeker seeker;

	public BallShooter(Seeker seeker) {
		this.seeker = seeker;

	}

	public void run() {
		int time = seeker.getRunningTime();
		while (time > 0) {
			if ((seeker.getDirection() == 1) || seeker.getDirection() == -1) {
				Motor.C.backward();
			}
			time--;
		}
	}

}
