package parts;

import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.LCD;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3IRSensor;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;

public class Seeker implements Runnable {

	private EV3IRSensor SeekSensor;
	private float[] seekerSample;
	private SampleProvider SK;
	private float direction;

	private int tempRunningTime = 2500;

	public Seeker() {
		Port myPort = LocalEV3.get().getPort("S4");
		SeekSensor = new EV3IRSensor(myPort);
		SK = SeekSensor.getSeekMode();
		seekerSample = new float[SK.sampleSize()];
	}

	public void run() {
		int time = tempRunningTime;
		while (time > 0) {
			LCD.clear();
			SK.fetchSample(seekerSample, 0);
			direction = seekerSample[0];
			LCD.drawString(direction + " dir", 1, 1);
			Delay.msDelay(15);
			time--;
		}
	}

	public int getDirection() {
		return (int) direction;
	}

	public int getRunningTime() {
		return tempRunningTime;
	}
}
