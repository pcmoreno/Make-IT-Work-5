package parts;

import lejos.hardware.motor.Motor;

public class MotorHandler {

	public MotorHandler() {
		Motor.A.setSpeed(100);
		Motor.B.setSpeed(100);
	}

	public void goforward() {
		Motor.A.backward();
		Motor.B.backward();
	}

	public void goLeftWithOne() {
		Motor.A.forward();
	}

	public void goRightWithOne() {
		Motor.B.forward();
	}

	public void turnLeft() {
		Motor.A.forward();
		Motor.B.backward();
	}

	public void turnRight() {
		Motor.A.backward();
		Motor.B.forward();
	}

}
