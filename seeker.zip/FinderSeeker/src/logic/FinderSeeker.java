package logic;

import lejos.hardware.Sound;
import parts.BallShooter;
import parts.MotorHandler;
import parts.Seeker;

public class FinderSeeker implements Runnable {

	private Thread threadFS;
	private Thread threadSeeker;
	private Thread threadKiller;

	private int direction;

	private MotorHandler motors;
	private BallShooter Killer;
	private FinderSeeker FS;
	private Seeker seeker;

	public FinderSeeker() {
		super();
		motors = new MotorHandler();
		seeker = new Seeker();
		Killer = new BallShooter(seeker);
		FS = new FinderSeeker();

		threadFS = new Thread(FS);
		threadSeeker = new Thread(seeker);
		threadKiller = new Thread(Killer);

	}

	public static void main(String[] args) {
		FinderSeeker FS = new FinderSeeker();
		FS.start();
	}

	private void start() {
		Sound.setVolume(50);
		Sound.beepSequenceUp();
		// seeker.run();
		threadFS.start();
		threadSeeker.start();
		threadKiller.start();
		Sound.beepSequence();
	}

	public void run() {
		int time = seeker.getRunningTime();
		while (time > 0) {
			direction = seeker.getDirection();
			if (direction <= 1 && direction >= -1) {
				//motors.goforward();
			} else if (direction < 25 && direction > 1) {
				motors.goRightWithOne();
			} else if (direction > -25 && direction < 1) {
				motors.goLeftWithOne();
			}
			time--;
		}

	}

}
