package logic;

public class Square {

	private int X;
	private int Y;
	private String name;

	public Square(int x, int y, String name) {
		this.X = x;
		this.Y = y;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public int getX() {
		return X;
	}

	public int getY() {
		return Y;
	}

	public String getType() {
		if (((X != 2)) && (Y != 2)) {
			return "corner";
		} else if ((X == Y) && (X == 2)) {
			return "center";
		} else if (((X != 2) && (Y == 2)) || ((X == 2) && (Y != 2))) {
			return "side";
		}

		return "not possible";
	}

	public boolean isOppositeTo(Square X) {
		if (this != (X)) {
			if (this.getType().equals(X.getType())) {
				if (this.getType().equals("corner")) {
					return ((this.getX() != X.getX()) && (this.getY() != X.getY()));
				} else if (this.getType().equals("center")) {
					return false;
				} else if (X.getType().equals("center")) {
					return false;
				} else if (X.getType().equals("side")) {
					return ((this.getX() == X.getX()) || (this.getY() == X.getY()));
				}
			}
		}
		return false;
	}

	public boolean isNextTo(Square X) {
		if ((X.getType().equals("center")) || (this.getType().equals("center"))) {
			return false;
		}
		if (!this.getType().equals(X.getType())) {
			if (this != X) {
				if (this.getType().equals("side")) {
					if (this.X == 2) {
						return (this.Y == X.getY());
					} else {
						return (this.X == X.getX());
					}
				} else if (this.getType().equals("corner")) {
					if ((this.X - X.getX()) == 0) {
						return ((this.Y - X.getY()) != 0);
					} else {
						return ((this.Y - X.getY()) == 0);
					}
				}
			}
		}
		return false;
	}
}
