package logic;

import java.util.ArrayList;
import java.util.Random;

import outputer.Drawer;

public class ArtificialBrain {

	private final ArrayList<Square> allSquares;
	private final Drawer drawer;
	private final Random random;
	private ArrayList<Square> moves;
	private boolean buzzyKickedAss = false;

	public ArtificialBrain(ArrayList<Square> allSquares, Drawer drawer, Random random, ArrayList<Square> moves) {
		this.allSquares = allSquares;
		this.drawer = drawer;
		this.random = random;
		this.moves = moves;
	}

	public String randomFirstMove() {
		int whatever = random.nextInt(9);
		return this.allSquares.get(whatever).getName();
	}

	public String secondMove() {
		if (!moves.get(moves.size() - 1).getType().equals("center")) {
			return "B2";
		} else {
			return "C1";
		}
	}

	public String fourthMove() {
		return sixthMove();
	}

	public String sixthMove() {
		String won = checkForWins();
		String Block = checkForBlocks(drawer.getGameArray());
		System.out.println("Did buzzy win?: " + won);
		System.out.println("Did buzzy block?: " + Block);
		if (!won.equals("NO")) {
			buzzyKickedAss = true;
		} else if (won.equals("NO")) {
			if (!Block.equals("NO")) {
				return Block;
			} else {
				int counter = 0;
				for (String A : drawer.getGameArray()) {
					counter++;
					if (A.contains(" ")) {
						System.out.println("WHAT> ");

						String WWW = "" + translateIntIntoString((A.indexOf(' ') + 1)) + (counter);
						System.out.println("random move was " + WWW);
						return WWW;

					}
				}
			}
		}
		return won;

	}

	private ArrayList<String> changeletters(char FromThis, char ToThis, ArrayList<String> Ar) {
		ArrayList<String> temp = new ArrayList<String>();
		temp.addAll(Ar);
		ArrayList<String> temp2 = new ArrayList<String>();
		for (String A : temp) {
			temp2.add(A.replace(FromThis, ToThis));
		}
		return temp2;
	}

	private String checkForWins() {
		ArrayList<String> temp = new ArrayList<String>();
		temp.addAll(drawer.getGameArray());
		temp = changeletters('x', 'K', temp);
		temp = changeletters('o', 'x', temp);
		temp = changeletters('K', 'o', temp);
		// System.out.println(temp.get(0)); //om te testen
		// System.out.println(temp.get(1));
		// System.out.println(temp.get(2));
		return checkForBlocks(temp);
	}

	private String checkForBlocks(ArrayList<String> GameArray) {
		// checks in Rows
		int counterLine = 1;
		for (String line : GameArray) {
			if (line.contains(" ")) {
				if (line.matches("xx | xx|x x")) {
					for (int x = 0; x < line.length(); x++) {
						if (line.charAt(x) == ' ') {
							System.out.println("used line code");
							return "" + translateIntIntoString(x + 1) + counterLine;
						}
					}
				}
			}
			counterLine++;
		} // Checks in Columns
		String[] cols = new String[3];
		cols[0] = new String(GameArray.get(0).charAt(0) + "" + GameArray.get(1).charAt(0) + GameArray.get(2).charAt(0));
		cols[1] = new String(GameArray.get(0).charAt(1) + "" + GameArray.get(1).charAt(1) + GameArray.get(2).charAt(1));
		cols[2] = new String(GameArray.get(0).charAt(2) + "" + GameArray.get(1).charAt(2) + GameArray.get(2).charAt(2));
		counterLine = 1;
		for (String line : cols) {
			if (line.contains(" ")) {
				if (line.matches("xx | xx|x x")) {
					for (int x = 0; x < line.length(); x++) {
						if (line.charAt(x) == ' ') {
							System.out.println("used Column code");
							return "" + translateIntIntoString(counterLine) + (x + 1);
						}
					}
				}
			}
			counterLine++;
		} // checks diagonals
		if (GameArray.get(1).charAt(1) == ('x')) {
			if ((GameArray.get(0).charAt(0) == 'x') && (GameArray.get(2).charAt(2) == ' ')) {
				return "C3";

			} else if ((GameArray.get(2).charAt(0) == 'x') && (GameArray.get(0).charAt(2) == ' ')) {
				return "C1";

			} else if ((GameArray.get(2).charAt(2) == 'x') && (GameArray.get(0).charAt(0) == ' ')) {
				return "A1";
			} else if ((GameArray.get(0).charAt(2) == 'x') && (GameArray.get(2).charAt(0) != 'o')) {
				return "A3";
			}
		}
		return "NO";

	}

	private String translateIntIntoString(int x) {
		if (x == 1) {
			return "A";
		} else if (x == 2) {
			return "B";
		} else {
			return "C";
		}
	}

	private Square getSquareFromName(String name) {
		for (Square S : this.allSquares) {
			if (S.getName().equals(name)) {
				return S;
			}
		}
		return null;
	}

	public boolean VICTORY() {
		return buzzyKickedAss;
	}
}
