package logic;

import java.util.ArrayList;
import java.util.Random;

import outputer.Drawer;
import userInterface.UserInterface;

public class Engine {
	private final Random random;
	private Square A1, A2, A3, B1, B2, B3, C1, C2, C3;
	private ArrayList<Square> squares;
	private final Drawer drawer;
	private final UserInterface UI;
	private ArrayList<Square> moveOrder;
	private ArtificialBrain AI;
	private boolean buzzyWins = false;
	private int turnCounter = 5;

	public Engine() {
		Initialize();
		drawer = new Drawer();
		UI = new UserInterface();
		random = new Random();
		this.moveOrder = new ArrayList<Square>();
		AI = new ArtificialBrain(squares, drawer, random, moveOrder);
	}

	private void doOneMove() {
		drawer.RedrawGame();
		drawer.Show();
		String chosenNow = UI.getChoice(ChosenSquares(moveOrder));
		for (Square E : squares) {
			if (E.getName().equals(chosenNow)) {
				drawer.drawMove(E, "x");
				drawer.RedrawGame();
				moveOrder.add(E);
			}
		}
	}

	public void Do() {

		doOneMove();

		String AImove = AI.secondMove();
		moveOrder.add(getSquareFromName(AImove));
		drawer.drawMove(getSquareFromName(AImove), "o");

		doOneMove();
		AImove = AI.fourthMove();
		moveOrder.add(getSquareFromName(AImove));
		drawer.drawMove(getSquareFromName(AImove), "o");
		while ((buzzyWins == false) && (turnCounter < 8)) {
			System.out.println("Turn " + turnCounter);
			turnCounter++;
			doOneMove();
			if (turnCounter < 8) {
				AImove = AI.sixthMove();
				moveOrder.add(getSquareFromName(AImove));
				drawer.drawMove(getSquareFromName(AImove), "o");
				if (AI.VICTORY()) {
					System.out.println("Buzzy says: YOU SUCK!");
					buzzyWins = true;
				}
				drawer.RedrawGame();
				drawer.Show();
			}
		}
		if (!AI.VICTORY()) {
			System.out.println("DRAW");
		}
	}

	private void Initialize() {
		A1 = new Square(1, 1, "A1");
		A2 = new Square(2, 1, "A2");
		A3 = new Square(3, 1, "A3");
		B1 = new Square(1, 2, "B1");
		B2 = new Square(2, 2, "B2");
		B3 = new Square(3, 2, "B3");
		C1 = new Square(1, 3, "C1");
		C2 = new Square(2, 3, "C2");
		C3 = new Square(3, 3, "C3");

		squares = new ArrayList<Square>();
		squares.add(A1);
		squares.add(B1);
		squares.add(C1);
		squares.add(A2);
		squares.add(B2);
		squares.add(C2);
		squares.add(A3);
		squares.add(B3);
		squares.add(C3);
	}

	private Square getSquareFromName(String name) {
		for (Square S : this.squares) {
			if (S.getName().equals(name)) {
				return S;
			}
		}
		return null;
	}

	private ArrayList<String> ChosenSquares(ArrayList<Square> S) {
		ArrayList<String> temp = new ArrayList<String>();
		for (Square X : S) {
			temp.add(X.getName());
		}
		return temp;
	}
}
