package logic;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Engine Eng = new Engine();
		Eng.Do();

	}

}
