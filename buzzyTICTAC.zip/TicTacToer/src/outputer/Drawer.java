package outputer;

import java.util.ArrayList;

import logic.Square;

public class Drawer {

	private StringBuilder game;

	private String A1 = " ", A2 = " ", A3 = " ", B1 = " ", B2 = " ", B3 = " ", C1 = " ", C2 = " ", C3 = " ";
	private String one, two, three;

	public Drawer() {
		game = new StringBuilder();
		BeginGame();
	}

	public void drawMove(Square X, String What) {
		if (X.getX() == 1) {
			if (X.getY() == 1) {
				A1 = What;
			} else if (X.getY() == 2) {
				A2 = What;
			} else {
				A3 = What;
			}
		} else if (X.getX() == 2) {
			if (X.getY() == 1) {
				B1 = What;
			} else if (X.getY() == 2) {
				B2 = What;
			} else if (X.getY() == 3) {
				B3 = What;
			}

		} else {
			if (X.getY() == 1) {
				C1 = What;
			} else if (X.getY() == 2) {
				C2 = What;
			} else if (X.getY() == 3) {
				C3 = What;
			}
		}

	}

	private void BeginGame() {
		game.append("  A B C \n");
		game.append("1  | | " + "\n");
		game.append("2  | | " + "\n");
		game.append("3  | | ");
	}

	public void Show() {
		System.out.println(game.toString());
	}

	public void RedrawGame() {
		String zero = "  A B C \n";
		one = "1 " + A1 + "|" + A2 + "|" + A3 + "\n";
		two = "2 " + B1 + "|" + B2 + "|" + B3 + "\n";
		three = "3 " + C1 + "|" + C2 + "|" + C3 + "\n";
		game = new StringBuilder();
		game.append(zero);
		game.append(one);
		game.append(two);
		game.append(three);
	}

	public String whatIsThere(Square X) {
		if (X.getY() == 1) {
			return one.substring(1 + X.getX(), 2 + X.getX());
		} else if (X.getY() == 2) {
			return two.substring(1 + X.getX(), 2 + X.getX());
		} else {
			return three.substring(1 + X.getX(), 2 + X.getX());
		}
	}

	public ArrayList<String> getGameArray() {
		ArrayList<String> output = new ArrayList<String>();
		output.add(A1 + A2 + A3);
		output.add(B1 + B2 + B3);
		output.add(C1 + C2 + C3);
		return output;
	}

}
