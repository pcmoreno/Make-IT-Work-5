package userInterface;

import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface {

	private final Scanner reader;
	private final ArrayList<String> chosenSquares;

	public UserInterface() {
		this.reader = new Scanner(System.in);
		this.chosenSquares = new ArrayList<String>();

	}

	public String getChoice(ArrayList<String> moves) {
		String chosen = "999";
		chosenSquares.addAll(moves);
		System.out.println("Choose a Square... (A1...C3)");
		while (!chosen.matches("^[A-C][1-3]$")) {
			chosen = reader.nextLine();
			if (chosenSquares.contains(chosen)) {
				System.out.println("Already taken. Pick another one");
				chosen = "999";
			}
		}
		chosenSquares.add(chosen);
		return chosen;
	}

}
